import Subscribe from "@/components/payment/Subscribe";
import React from "react";

const SubscribePage = () => {
  return <Subscribe />;
};

export default SubscribePage;