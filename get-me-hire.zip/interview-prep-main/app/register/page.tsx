import Register from "@/components/auth/Register";
import React from "react";

const RegisterPage = () => {
  return <Register />;
};

export default RegisterPage;