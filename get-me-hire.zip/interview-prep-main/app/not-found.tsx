import NotFound from "@/components/layout/not-found/NotFound";
import React from "react";

const NotFoundPage = () => {
  return <NotFound />;
};

export default NotFoundPage;