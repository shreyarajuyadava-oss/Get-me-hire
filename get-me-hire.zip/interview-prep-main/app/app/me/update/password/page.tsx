import UpdatePassword from "@/components/auth/UpdatePassword";
import React from "react";

const UpdatePasswordPage = () => {
  return <UpdatePassword />;
};

export default UpdatePasswordPage;