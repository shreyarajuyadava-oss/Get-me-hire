import UpdateProfile from "@/components/auth/UpdateProfile";
import React from "react";

const UpdateProfilePage = () => {
  return <UpdateProfile />;
};

export default UpdateProfilePage;