import Unsubscribe from "@/components/payment/Unsubscribe";
import React from "react";

const UnsubscribePage = () => {
  return <Unsubscribe />;
};

export default UnsubscribePage;