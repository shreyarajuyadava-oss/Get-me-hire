import NewInterview from "@/components/interview/NewInterview";
import React from "react";

const NewInterviewPage = () => {
  return <NewInterview />;
};

export default NewInterviewPage;