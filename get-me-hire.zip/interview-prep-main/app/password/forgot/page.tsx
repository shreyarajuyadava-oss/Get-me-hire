import ForgotPassword from "@/components/auth/ForgotPassword";
import React from "react";

const ForgotPasswordPage = () => {
  return <ForgotPassword />;
};

export default ForgotPasswordPage;