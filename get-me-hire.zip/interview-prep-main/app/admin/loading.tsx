import Loader from "@/components/layout/loader/Loader";
import React from "react";

const AppLoading = () => {
  return <Loader />;
};

export default AppLoading;