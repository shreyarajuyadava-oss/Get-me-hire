export const siteConfig = {
  name: "Interview Prep",
  description: "Prepare for Interview with AI",
};