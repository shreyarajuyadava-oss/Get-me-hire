export const industries = [
  "Software Development",
  "Technology",
  "Finance",
  "Healthcare",
  "Education",
  "Manufacturing",
  "Government",
];

export const industryTopics = {
  "Software Development": [
    "Frontend Development",
    "Backend Development",
    "Full Stack Development",
    "React.js",
  ],
  Technology: ["AI & Machine Learning", "Cybersecurity", "Cloud Computing"],
  Finance: ["Investment Banking", "Financial Analysis", "Accounting"],
  Healthcare: ["Medical Research", "Healthcare Administration", "Nursing"],
  Education: ["Teaching", "Curriculum Development", "Educational Technology"],
  Manufacturing: [
    "Production Management",
    "Quality Control",
    "Supply Chain Management",
  ],
  Government: ["Public Policy", "Administration", "Law Enforcement"],
  
};

export const interviewTypes = [
  "Technical",
  "Behavioral",
  "In-Person",
];

export const interviewDifficulties = [
  "Entry Level",
  "Mid Level",
  "Senior Level",
];