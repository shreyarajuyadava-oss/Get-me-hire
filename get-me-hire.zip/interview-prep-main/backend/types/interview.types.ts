export interface InterviewBody {
  industry: string;
  type: string;
  topic: string;
  role: string;
  numOfQuestions: number;
  difficulty: string;
  duration: number;
  user: string;
}